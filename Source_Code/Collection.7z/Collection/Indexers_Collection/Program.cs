﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexers_Collection
{
    class IndexerExample
    {
        private int[] _array = new int[5];
        public int this[int index]
        {
            get
            {
                return _array[index];
            }
            set
            {
                _array[index] = value;
            }
        }

        public class Program
        {
            static void Main(string[] args)
            {
                var example = new IndexerExample();
                example[0] = 10;
                example[1] = 20;
                Console.WriteLine(example[0]);
                Console.WriteLine(example[1]);

            }
        }
    }
}