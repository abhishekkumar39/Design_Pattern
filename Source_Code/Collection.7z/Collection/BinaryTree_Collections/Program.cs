﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTree_Collections
{
    class Node
    {
        public int Data;
        public Node Left;
        public Node Right;
        public Node(int data)
        {
            Data = data;
            Left = Right = null;
        }
    }
    class BinaryTree
    {
        public Node Root;
        public void InOrderTravesal(Node node)
        {
            if (node == null)
                return;
            InOrderTravesal(node.Left);
            Console.WriteLine(node.Data);
            InOrderTravesal(node.Right);
        }
    }
        public class Program
        {
            static void Main(string[] args)
            {
              BinaryTree tree = new BinaryTree();
             tree.Root=new Node(1);
             tree.Root.Left=new Node(2);
             tree.Root.Right=new Node(3);
             tree.InOrderTravesal(tree.Root);

            }
        }
    }

