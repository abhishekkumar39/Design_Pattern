﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary_Collection
{
    public class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> capitals = new Dictionary<string, string>();
            capitals.Add("USA", "washington,D.C");
            capitals.Add("France", "Paris");

            Console.WriteLine(capitals["France"]);
            }
        }
    }

