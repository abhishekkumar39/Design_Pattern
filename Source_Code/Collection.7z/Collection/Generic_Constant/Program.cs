﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Constaints
{
    class Calculator<T> where T : struct
    {
        public T Add(T a, T b)
        {
            dynamic x = a;
            dynamic y = b;
            return x + y;
        }
    }
        public class Program
        {
            static void Main(string[] args)
            {
            var calculator=new Calculator<int>();
            Console.WriteLine(calculator.Add(3, 5));
             var doubleCalculator=new Calculator<double>();
            Console.WriteLine(doubleCalculator.Add(2.5,4.5));

            }
        }
    }
