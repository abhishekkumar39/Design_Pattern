﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList numbers = new ArrayList() { 1, 2, 3, 4, 5 };
            numbers.RemoveAt(2);
            foreach (var number in numbers)
            {
                Console.WriteLine(number);
            }
        }
    }
}
