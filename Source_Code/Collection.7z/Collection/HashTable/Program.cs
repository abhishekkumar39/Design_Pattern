﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hash_Table
{
     public class Program
    {
        static void Main(string[] args)
        {
            Hashtable hashTable= new Hashtable();
            hashTable.Add("Apple", 10);
            hashTable.Add("Banana", 20);
            hashTable["Apple"] = 15;
            hashTable.Remove("Banana");
            foreach (DictionaryEntry entry in hashTable)
            {
                Console.WriteLine(entry.Key);
                Console.WriteLine(entry.Value);
            }
        }
    }
}
