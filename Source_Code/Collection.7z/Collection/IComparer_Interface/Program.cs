﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IComparer_Interface
{
    class StringLengthComparar : IComparer<string>
    {
        public int Compare(string x, string y)
        {
            return x.Length.CompareTo(y.Length);
        }

        public class Program
        {
            static void Main(string[] args)
            {
                List<string> words = new List<string>() { "apple", "banana", "cherry" };
                words.Sort(new StringLengthComparar());
                foreach (var word in words)
                {
                    Console.WriteLine(word);
                }
            }
        }
    }
}
