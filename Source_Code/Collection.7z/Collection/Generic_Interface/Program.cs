﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Interface
{
    interface IRepository<T>
    {
        void Add(T item);
        T Get(int id);
    }
    class Repository<T> : IRepository<T>
    {
        private T[] items=new T[10];
       public void Add(T item)
        {
            items[0]=item;
        }
        public T Get(int id)
        {
            return items[id];
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            var repo=new Repository<string>();
            repo.Add("Hello");
            Console.WriteLine(repo.Get(0));
        }
    }
}
