﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Method
{
     class Program
    {
        static void Swap<T>(ref T a, ref T b)
        {
            T temp = a;
            a=b; 
            b=temp;
        }

        static void Main(string[] args)
        {
            int x = 1;
            int y=2;
            Swap(ref x, ref y);
            Console.WriteLine($"x:{x}, y:{y}");
            string s1 = "Hello", s2 = "World";
            Swap(ref s1, ref s2);
            Console.WriteLine($"s1:{s1},s2:{s2}");
        }
    }
}
