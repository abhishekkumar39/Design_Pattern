﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedList_Generic
{
    public class Program
    {
        static void Main(string[] args)
        {
            LinkedList<string> linkedlist = new LinkedList<string>();
            linkedlist.AddLast("End");
            linkedlist.AddFirst("start");
            linkedlist.AddAfter(linkedlist.First, "Middle");
            foreach (var item in linkedlist)
            {
                    Console.WriteLine(item);

            }
        }
    }
}
