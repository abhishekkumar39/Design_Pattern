﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Queue_Collection
{
    public class Program
    {
        static void Main(string[] args)
        {
            Queue queue = new Queue();
            queue.Enqueue("first");
            queue.Enqueue("Second");
            queue.Enqueue("Third");
 
            while (queue.Count > 0) 
            {
                Console.WriteLine(queue.Dequeue());
            }
        }
    }
}
