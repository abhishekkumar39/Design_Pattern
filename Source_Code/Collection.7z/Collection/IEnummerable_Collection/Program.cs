﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnummerable_Collection
{
    class NumberColection : IEnumerable<int>
    {
        private List<int> _numbers = new List<int> { 1, 2, 3, 4, 5 };
        public IEnumerator<int> GetEnumerator()
        {
            return _numbers.GetEnumerator();
        }
        IEnumerator IEnumerable.GetEnumerator()
        { 
            return GetEnumerator();
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            var numbers=new NumberColection();
            foreach (var number in numbers)
            {
                Console.WriteLine(number);
            }
            
        }
    }
}
