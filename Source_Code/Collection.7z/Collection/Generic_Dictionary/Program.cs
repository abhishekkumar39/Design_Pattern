﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Dictionary
{
    public class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> employees = new Dictionary<int, string>();
            employees.Add(1, "Alice");
            employees.Add(2, "Bob");
            employees[2] = "charlie";
            Console.WriteLine($"Employee 2:{employees[2]}");
            foreach (var employee in employees)
            {
                Console.WriteLine($"{employee.Key}:{employee.Value}");
            }

        }
    }
}
