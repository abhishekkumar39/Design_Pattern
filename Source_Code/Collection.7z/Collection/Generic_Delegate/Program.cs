﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_Delegate
{
    delegate T Operation<T>(T a,T b);

    public class Program
    {
        static int Add(int x, int y) => x + y;
        static string Concate(string x, string y) => x + y;

        static void Main(string[] args)
        {
            Operation<int> intOperation = Add;
            Console.WriteLine(intOperation(5,10));  
            Operation<string> stringOperation = Concate;
            Console.WriteLine(stringOperation("Hello,", "World"));
        }
    }
}
