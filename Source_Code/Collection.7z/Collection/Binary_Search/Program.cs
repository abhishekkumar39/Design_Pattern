﻿using Binary_Search;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Binary_Search
{
    class Node
    {
        public int Data;
        public Node Left;
        public Node Right;
        public Node(int data)
        {
            Data = data;
            Left = Right = null;
        }

        class BinarySearchTree
        {
            public Node Root;
            public void insert(int data)
            {
                Root = InsertRec(Root, data);
            }
            private Node InsertRec(Node root, int data)
            {
                if (root == null)
                {
                    root = new Node(data);
                    return root;
                }
                if (data < root.Data)
                {
                    root.Left = InsertRec(root.Left, data);
                }
                else if (data > root.Data)
                    root.Right = InsertRec(root.Right, data);
                return root;
            }

            public bool Search(int data)
            {
                return SearchRec(Root, data) != null;
            }
            public Node SearchRec(Node root, int data)
            {
                if (root == null || root.Data == data)
                    return root;
                if (data < root.Data)
                    return SearchRec(root.Left, data);
                return SearchRec(root.Right, data);
            }
        }
        public class Program
        {
            static void Main(string[] args)
            {
                BinarySearchTree bst = new BinarySearchTree();
                bst.insert(50);
                bst.insert(30);
                bst.insert(70);
                Console.WriteLine(bst.Search(30));
                Console.WriteLine(bst.Search(100));
            }
        }
    }
}