﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IComparable_Collection
{
    class Student : IComparable<Student>
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public int CompareTo(Student other)
        {
            return this.Age.CompareTo(other.Age);
        }


        public class Program
        {
            static void Main(string[] args)
            {
                List<Student> students = new List<Student> {
                new Student { Name="Alice",Age=22},
                 new Student { Name = "Bob", Age = 20 },
                  new Student { Name = "Charlie", Age = 23 }
                  };

                  students.Sort();
                  foreach (var student in students)
                {
                    Console.Write(student.Name);
                    Console.WriteLine(student.Age);
                }
            }
        }
    }
}
