﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic_List
{
    public class Program
    {

        static void Main(string[] args)
        {
            List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };
            numbers.Add(6);
            numbers.Remove(3);
            int index = numbers.FindIndex(x => x == 5);
            Console.WriteLine($"Index of 5:{index}");
            foreach (var number in numbers)
            {
                Console.WriteLine(number);
            }
        }
    }
}