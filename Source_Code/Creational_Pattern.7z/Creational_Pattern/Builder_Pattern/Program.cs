﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Builder_Pattern
{
    public class Product
    {
        public string Part1 { get; set; }
        public string Part2 { get; set; }
        public string Part3 { get; set; }
        public void ShowInfo()
        {
            Console.WriteLine($"Part 1:{Part1}");
            Console.WriteLine($"Part 2:{Part2}");
            Console.WriteLine($"Part 3:{Part3}");
        }
    }

    public abstract class Builder
    {
        public abstract void BuilPart1();
        public abstract void BuilPart2();
        public abstract void BuilPart3();
        public abstract Product GetResult();

    }
    public class ConcreteBuilder : Builder
    {
        private Product product = new Product();

        public override void BuilPart1()
        {
            product.Part1 = "Part 1 built";
        }
        public override void BuilPart2()
        {
            product.Part2 = "Part 2 built";
        }
        public override void BuilPart3()
        {
            product.Part3 = "Part 3 built";
        }
        public override Product GetResult()
        {
            return product;
        }

    }
    public class Director
    {
        private Builder builder;

        public Director(Builder builder)
        {
            this.builder = builder;
        }
        public void Constuctor()
        {
            builder.BuilPart1();
            builder.BuilPart2();
            builder.BuilPart3();
        }
        public class Program
        {
            public static void Main(string[] args)
            {
                Builder builder = new ConcreteBuilder();
                Director director = new Director(builder);
                director.Constuctor();
                Product product = builder.GetResult();
                product.ShowInfo();
                Console.WriteLine(product);


            }
        }
    }
}