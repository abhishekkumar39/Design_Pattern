﻿using Adapter_Pattern;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapter_Pattern
{
    interface ITarget
    {
        void Request();
    }
    class Adaptee
    {
        public void SpecificRequest()
        {
            Console.WriteLine("Adaptee's specific request");
        }
    }
    class Adapter : ITarget
    {
        private readonly Adaptee _adaptee;
    
    public Adapter(Adaptee adaptee)
    {
        _adaptee = adaptee;
    }
    public void Request()
    {
        _adaptee.SpecificRequest();
    }
}
    
   class client
{
    public void MakeRequest(ITarget target)
    {
        target.Request();
    }
}

    public class Program
    {
        static void Main(string[] args)
        {
            Adaptee adaptee = new Adaptee();
            ITarget adapter = new Adapter(adaptee);
            client client = new client();
            client.MakeRequest(adapter);
            Console.ReadKey();

        }
    }
}
