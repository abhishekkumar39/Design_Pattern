﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype_pattern
{
    public interface IPrototype
    {
        IPrototype Clone();

    }
    public class ConcretePrototype : IPrototype
    {
        public int Id { get; set; }
        public string Name { get; set; }


        public ConcretePrototype(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public IPrototype Clone()
        {
            return (IPrototype)this.MemberwiseClone();
        }
        public void DisplayInfo()
        {
            Console.WriteLine($"Id:{Id}, Name:{Name}");
        }

        public class Program
        {
            static void Main(string[] args)
            {
                ConcretePrototype prototype = new ConcretePrototype(1, "Prototype 1");
                ConcretePrototype clonedPrototype = (ConcretePrototype)prototype.Clone();
                clonedPrototype.Name = "Cloned Prototype";
                Console.WriteLine($"Original Prototype");
                prototype.Clone();
                Console.WriteLine("Closed prototype:");
                clonedPrototype.DisplayInfo();
                Console.ReadKey();

            }
        }
    }

}