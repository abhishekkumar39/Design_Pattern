﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy_Pattern
{
    public interface ISubject
    {
        void Request();
    }
    public class RealSubject : ISubject
    {
        public void Request()
        {
            Console.WriteLine("RealSubject : Handling Request");
        }
    }

    public class Proxy : ISubject
    {
        private RealSubject realSubject;

        public void Request()
        {
            if (realSubject == null)
            {
                Console.WriteLine("Proxy : Creating RealSubject");
                realSubject = new RealSubject();
            }

            Console.WriteLine("Proxy : Forwading request to RealSubject.");
            realSubject.Request();
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            Proxy proxy = new Proxy();
            proxy.Request();
            Console.ReadKey();
        }
    }
}
