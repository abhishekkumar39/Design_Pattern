﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

namespace Abstract_Factory

{

    using System;

    public interface IproductA

    {

        void DisplayInfo();

    }

    public class ConcreteProductA1 : IproductA

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Concrete Product A1");

            Console.ReadLine();

        }

    }

    public class ConcreteProductA2 : IproductA

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Concrete Product A2");

            Console.ReadLine();

        }

    }

    public interface IproductB

    {

        void DisplayInfo();

    }

    public class ConcreteProductB1 : IproductB

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Concrete Product B1");

            Console.ReadLine();

        }

    }

    public class ConcreteProductB2 : IproductB

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Concrete Product B2");

            Console.ReadLine();

        }

    }

    public interface IAbstractFactory

    {

        IproductA CreateProductA();

        IproductB CreateProductB();

    }

    public class ConcreteFactory1 : IAbstractFactory

    {

        public IproductA CreateProductA()

        {

            return new ConcreteProductA1();

        }

        public IproductB CreateProductB()

        {

            return new ConcreteProductB1();

        }

    }

    public class ConcreteFactory2 : IAbstractFactory

    {

        public IproductA CreateProductA()

        {

            return new ConcreteProductA2();

        }

        public IproductB CreateProductB()

        {

            return new ConcreteProductB2();

        }

    }


    public class Program

    {

        static void Main(string[] args)

        {

            IAbstractFactory factory1 = new ConcreteFactory1();

            IproductA iproductA1 = factory1.CreateProductA();

            IproductB iproductB1 = factory1.CreateProductB();

            iproductA1.DisplayInfo();

            iproductB1.DisplayInfo();

            IAbstractFactory factory2 = new ConcreteFactory2();

            IproductA iproductA2 = factory2.CreateProductA();

            IproductB iproductB2 = factory2.CreateProductB();

            iproductA2.DisplayInfo();

            iproductB2.DisplayInfo();

        }

    }

}

