﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Security.Cryptography.X509Certificates;
using System.Text;

using System.Threading.Tasks;

namespace Decorator_Pattern

{

    public interface ICar

    {

        string GetDescription();

        double GetCost();

    }

    public class EconomyCar : ICar

    {

        public string GetDescription()

        {

            return "Economy Car";

        }

        public double GetCost()

        {

            return 20000.0;

        }

    }

    public abstract class CarDecortor : ICar
    {

        protected ICar _Car;

        public CarDecortor(ICar car)

        {

            _Car = car;

        }

        public virtual string GetDescription()

        {

            return _Car.GetDescription();

        }

        public virtual double GetCost()

        {

            return _Car.GetCost();

        }

    }

    public class SunRoofDecorator : CarDecortor

    {

        public SunRoofDecorator(ICar car) : base(car) { }

        public override string GetDescription()

        {

            return $"{base.GetDescription()} with sun Roof";

        }

        public override double GetCost()

        {

            return base.GetCost() + 1500.0;

        }
    }

    public class LeatherSeatSDecorater : CarDecortor
    {
        public LeatherSeatSDecorater(ICar car) : base(car) { }

        public override string GetDescription()
        {
            return $"{base.GetDescription()} with Leater Seat";
        }
        public override double GetCost()
        {
            return base.GetCost() + 1000.0;
        }

    }

    public class Program

    {
        static void Main(string[] args)
        {
            ICar myCar1 = new EconomyCar();
            ICar myCar2 = new EconomyCar();
            myCar1 = new SunRoofDecorator(myCar1);
            myCar2 = new LeatherSeatSDecorater(myCar2);
            Console.WriteLine($"Description:{myCar1.GetDescription()}");
            Console.WriteLine($"Cost:{myCar1.GetCost()}");
            Console.WriteLine($"Description:{myCar2.GetDescription()}");
            Console.WriteLine($"Cost:{myCar2.GetCost()}");
        }

    }

}