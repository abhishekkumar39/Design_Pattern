﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge_Pattern
{
    public abstract class Shape
    {
        protected IRenderer renderer;

        public Shape(IRenderer renderer)
        {
            this.renderer = renderer;
        }

        public abstract void Draw();
    }
    public interface IRenderer
    {
        void RenderCircle(float radius);
    }
    public class Renderer : IRenderer
    {
        public void RenderCircle(float radius)
        {
            Console.WriteLine($"drawing a circle with radius {radius}");
        }
    }
    public class Circle : Shape
    {
        private float radius;

        public Circle(float radius, IRenderer renderer):base(renderer) 
        {
            this.radius = radius;

        }
        public override void Draw()
        {
            {
                renderer.RenderCircle(radius);
            }
        }

        public class Program
        {
            static void Main(string[] args)
            {
                IRenderer renderer = new Renderer();
                Shape circleShape = new Circle(5, renderer);
                Shape bigCircleShape = new Circle(10, renderer);

                circleShape.Draw();
                bigCircleShape.Draw();
                Console.ReadKey();
            }
        }
    }
}
