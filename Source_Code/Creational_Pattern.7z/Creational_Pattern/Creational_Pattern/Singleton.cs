﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Creational_Pattern
{
    public class Singleton
    {
        // Stativc hold the instance of the singlton

        private static Singleton instance;

        // thread safe

        private static readonly object _lock=new object();

        //Private constructor to prevent instantiation of the class
        private Singleton()
        {
            // Initialization code here
        }

        public static Singleton GetInstance()
        {
            lock (_lock)
            {
                if (instance == null)
                {
                    instance = new Singleton();
                }
                return instance;
            }
        }
          
    }
}
