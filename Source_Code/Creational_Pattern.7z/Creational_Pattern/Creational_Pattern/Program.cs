﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Creational_Pattern
{
    public class Program
    {
       
        static void Main(string[] args)
        {
            Singleton singleton1=Singleton.GetInstance();
            Singleton singleton2=Singleton.GetInstance();

            Console.WriteLine($"Are singleton1 and singleton2 the same instance?{singleton1==singleton2}");
            Console.ReadKey();
        }
    }
}
