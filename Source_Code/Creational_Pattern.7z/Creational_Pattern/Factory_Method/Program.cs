﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method
{
    using System;
    

    public interface IProduct
    {
        void ShowInfo();
    }
    public class ConcreteProductA : IProduct
    {
        public void ShowInfo()
        {
            Console.WriteLine("This is Concreate Product A");
            Console.ReadKey();
        }
    }
    public class ConcreteProductB : IProduct
    {
        public void ShowInfo()
        {
            Console.WriteLine("This is Concrete Product B");
            Console.ReadKey();
        }
    }

    public abstract class Creator
    {
        public abstract IProduct FactoryMethod();
    }
    public class ConcreteCreatorA : Creator
    {
        public override IProduct FactoryMethod()
        {
            return new ConcreteProductA();
        }
    }
    public class ConcreteCreatorB : Creator
    {
        public override IProduct FactoryMethod()
        {
            return new ConcreteProductB();
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Creator creatorA = new ConcreteCreatorA();
            IProduct productA = creatorA.FactoryMethod();
            productA.ShowInfo();
            Creator creatorB = new ConcreteCreatorB();
            IProduct productB = creatorB.FactoryMethod();
            productB.ShowInfo();    


        }
    }
    
}
