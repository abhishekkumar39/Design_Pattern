﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Composit_Pattern
{
    public interface IComponent
    {
        void Display(int depth);
    }

    public class Leaf : IComponent
    {
        private string name;
        public Leaf(string name)
        {
            this.name = name;
        }

        public void Display(int depth)
        {
            Console.WriteLine(new string(' ', depth) + name);
        }
    }

    public class Composite : IComponent
    {
        private string name;
        private List<IComponent> children = new List<IComponent>();
        public Composite(string name)
        {
            this.name = name;
        }

        public void Add(IComponent component)
        {
            children.Add(component);
        }
        public void Remove(IComponent component)
        {
            children.Remove(component);
        }
        public void Display(int depth)
        {
            Console.WriteLine(new String('-', depth) + name);

            foreach (var component in children)
            {
                component.Display(depth + 2);
            }
        }
        public class Program
        {
            static void Main(string[] args)
            {
                Composite root = new Composite("Root");
                root.Add(new Leaf("Leaf A"));
                root.Add(new Leaf("Leaf B"));

                Composite compositeX = new Composite("Composite X");
                compositeX.Add(new Leaf("Leaf XA"));
                compositeX.Add(new Leaf("Leaf XB"));

                Composite compositeY = new Composite("Composite X");
                compositeY.Add(new Leaf("Leaf YA"));
                compositeY.Add(new Leaf("Leaf YB"));

                root.Add(compositeX);
                root.Add(compositeY);

                root.Display(0);
                root.Display(1);
            }
        }
    }
}


