﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    public class Program
    {
      public static void Main(string[] args)
        {
            //udent s = new Student();
           //.Name = "Abhishek";
           //onsole.WriteLine(s.Name);

            Counter.Increment();
            Counter.Increment();
            Counter.Increment();
        }
    }
}
