﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs_Concepts
{
    public class Car
    {
        public String Make {  get; set; }  
        public String Model { get; set; }

        private int Year;
        public void SetYear(int year)
        {
            if (year >= 2000)
            {
                this.Year = year;
            }
            else
            {
                Console.WriteLine("Year must be greater than 2000");
            }
        }

        public int GetYear()
        {
            return Year;

        }  

        public void DisplayInfo()
        {
            Console.WriteLine($"Brand:{Make},Model:{Model},Year:{Year}");
        }
    }


}
