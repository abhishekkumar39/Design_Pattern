﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs_Concepts
{
    public class Program
    {
       public static void Main(string[] args)
        {
            Bike myBike = new Bike();
            myBike.Brand = "Yamaha";
            myBike.Model = "R15";
          
            myBike.EngineCapacity = 150;
     
            myBike.DisplayInfo();
          
        }
    }
}
