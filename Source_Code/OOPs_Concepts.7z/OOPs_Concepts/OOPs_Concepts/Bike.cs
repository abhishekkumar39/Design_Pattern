﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs_Concepts
{
    public class Bike:Vehicle
    {
        public int EngineCapacity{ get; set; }
        public override void DisplayInfo()
        {
            base.DisplayInfo();

            Console.WriteLine($"Engine Capacity:{EngineCapacity}cc");
        }
    }
}
