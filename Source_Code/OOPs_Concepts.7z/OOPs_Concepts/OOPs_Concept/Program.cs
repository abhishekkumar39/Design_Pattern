﻿using OOPs_Concepts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs_Concept
{
    public class Program
    {
        static void Main(string[] args)
        {
            Car myCar = new Car();
            myCar.Make = "Maruti";
            myCar.Model = "Alto";

            myCar.Year = 2024;

            myCar.DisplayInfo();
           
        }
    }
}
