﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs_Concepts
{
    public class Car
    {
        public String Make {  get; set; }  
        public String Model { get; set; }

        public int Year { get; set; }
        public void DisplayInfo()
        {
            Console.Write($"Brand:{Make},Model:{Model},Year:{Year}");
        }
       
       
    }


}
