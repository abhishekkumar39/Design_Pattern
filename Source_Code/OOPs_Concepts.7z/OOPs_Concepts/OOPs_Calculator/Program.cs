﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs_Calculator
{
    public class Program
    {
        static void Main(string[] args)
        {
            Calculator cal= new Calculator();
            Console.WriteLine("Addition");
            double result = cal.Add(5, 3);
            Console.WriteLine(result);
            Console.WriteLine("Substraction");
            result = cal.Sub(5,3);  
            Console.WriteLine(result);
            Console.WriteLine("Multiplication");
            result = cal.Multiply(5,3);
            Console.WriteLine(result);
            Console.WriteLine("Division");
            result = cal.Divide(5,3);
            Console.WriteLine(result);
        }
    }
}
