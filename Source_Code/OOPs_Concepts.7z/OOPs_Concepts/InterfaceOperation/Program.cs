﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceOperation
{
    public class Program
    {
       public static void Main(string[] args)
        {
            IMovable om = new Robot();
            om.Move();    
            
        }
    }
}
