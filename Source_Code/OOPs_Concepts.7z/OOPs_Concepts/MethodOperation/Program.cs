﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOperation
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Mathoperations mathops = new Mathoperations();
            Console.WriteLine(mathops.Add(3,5));
            Console.WriteLine(mathops.Add(4.5,3.5));
           
            
        }
    }
}
