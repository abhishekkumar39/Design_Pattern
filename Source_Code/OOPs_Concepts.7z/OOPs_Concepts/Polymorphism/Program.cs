﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism
{
    public class Program
    {
        static void Main(string[] args)
        {
            shape s = new shape ();
            s.Draw();
            s = new Rectangle();
            s.Draw();
            s = new Circle();
            s.Draw();

        }
    }
}
