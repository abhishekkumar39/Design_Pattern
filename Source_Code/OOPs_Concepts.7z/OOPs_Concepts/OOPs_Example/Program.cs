﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs_Example
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BankAccount bankAccount = new BankAccount();
            Console.WriteLine("Bank Balance: " + bankAccount.Balance);
            Console.WriteLine("Amount Deposited in Bank");
            bankAccount.Deposit(2000);
            bankAccount.GetBalance();
            Console.WriteLine("Amount After WithDrawal From Bank");
            bankAccount.Withdraw(5000);
            bankAccount.GetBalance();
        }
    }
}
