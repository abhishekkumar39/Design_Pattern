﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace OOPs_Example
{
    public class BankAccount
    {
        private int accountnumber = 9876345;
        private decimal balance = 12000;

        public decimal Balance
        {
            get { return balance; } set { balance = value; }
        }
        public void GetBalance()
        {
            Console.WriteLine(this.balance);
        }
        public decimal Deposit(decimal amount)
        {
            this.balance += amount;
            return this.balance;
        }
        public decimal Withdraw(decimal amount)
        {
            this.balance -= amount;
            return this.balance;
        }
    }
}
   
