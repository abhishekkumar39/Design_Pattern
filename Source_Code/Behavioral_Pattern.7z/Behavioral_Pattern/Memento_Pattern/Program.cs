﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memento_Pattern
{
    class Originator
    {
        private string state;
        public string State
        {
            get { return state; }
            set
            {
                state = value;
                Console.WriteLine("State set to : " + state);
            }
        }
        public Memento Save()
        {
            return new Memento(state);
        }
        public void Restore(Memento memento)
        {
            state = memento.State;
            Console.WriteLine("State restore to :" + state);
        }
    }
    class Memento
    {
        public string State { get; }
        public Memento(string state)
        {
            State = state;
        }
    }
    class Caretaker
    {
        public Memento Memento { get; set; }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Originator originator = new Originator();
            Caretaker caretaker = new Caretaker();

            originator.State = "State1";
            caretaker.Memento=originator.Save();
            originator.State = "State2";

            originator.Restore(caretaker.Memento);
            Console.ReadKey();  

        }
    }
}
