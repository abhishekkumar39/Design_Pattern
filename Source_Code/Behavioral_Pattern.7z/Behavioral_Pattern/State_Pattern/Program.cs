﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace State_Pattern
{
    class Player
    {
        private State state;
        public Player()
        {
            state = new StandbyState();
        }
        public void ChangeState(State newState)
        {
            state = newState;
        }
        public void PressPlay()
        {
            state.PressPlay(this);
        }
        public void PressPause()
        {
            state.PressPause(this);
        }
    }
    interface State
    {
        void PressPlay(Player player);
        void PressPause(Player player);
    }
    class StandbyState : State
    {
        public void PressPlay(Player player)
        {
            Console.WriteLine("Playing....");
            player.ChangeState(new PlayingState());
        }
        public void PressPause(Player player)
        {
            Console.WriteLine("Cannot pause, the player is not playing yet.");
        }
    }
    class PlayingState : State
    {
        public void PressPlay(Player player)
        {
            Console.WriteLine("Already playing");
        }
        public void PressPause(Player player)
        {
            Console.WriteLine("Paused....");
            player.ChangeState(new PausedState());
        }
    }
    class PausedState : State
    {
        public void PressPlay(Player player)
        {
            Console.WriteLine("Resuming play....");
            player.ChangeState(new PausedState());
        }
        public void PressPause(Player player)
        {
            Console.WriteLine("Already paused");
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Player player = new Player();
            player.PressPause();
            player.PressPlay();
            player.PressPlay();
            player.PressPause();
            player.PressPause();
            player.PressPlay();
            Console.ReadKey();
        }
    }
}
