﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chainof_Responsibility_Pattern
{
    public interface IHandler
    {
        void SetNext(IHandler handler);
        void HandleRequest(int request);
    }
    public class ConcreteHandler1 : IHandler
    {
        private IHandler _nextHandler;
        public void SetNext(IHandler handler)
        {
            _nextHandler = handler; 
        }
        public void HandleRequest(int request)
        {
            if (request <= 0)
            {
                Console.WriteLine($"Request {request} handler by ConcreateHanler1");
            }
            else if (_nextHandler != null)
            {
                _nextHandler.HandleRequest(request);
            }
            else
            {
                Console.WriteLine("End of the chain. Rquest not Handled ");
            }
        }
    }

    public class ConcreteHandler2 : IHandler
    {
        private IHandler _nextHandler;
        public void SetNext(IHandler handler)
        {
            _nextHandler = handler;
        }
        public void HandleRequest(int request)
        {
            if (request > 10 && request <=20)
            {
                Console.WriteLine($"Request {request} handler by ConcreateHanler2");
            }
            else if (_nextHandler != null)
            {
                _nextHandler.HandleRequest(request);
            }
            else
            {
                Console.WriteLine("End of the chain. Rquest not Handled ");
            }
        }
    }

    public class ConcreteHandler3 : IHandler
    {
        private IHandler _nextHandler;
        public void SetNext(IHandler handler)
        {
            _nextHandler = handler;
        }
        public void HandleRequest(int request)
        {
            if (request > 20 && request <= 30)
            {
                Console.WriteLine($"Request {request} handler by ConcreateHanler2");
            }
            else if (_nextHandler != null)
            {
                _nextHandler.HandleRequest(request);
            }
            else
            {
                Console.WriteLine("End of the chain. Rquest not Handled ");
            }
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            var handler1  = new ConcreteHandler1(); 
            var handler2 = new ConcreteHandler2();
            handler1.SetNext(handler2);
            handler1.HandleRequest(5);
            handler1.HandleRequest(15);
            handler1.HandleRequest(25);
            var handler3= new ConcreteHandler3();
            handler3.SetNext(handler3);
            handler3.HandleRequest(25);
            
            Console.ReadKey();  


        }
    }
}
