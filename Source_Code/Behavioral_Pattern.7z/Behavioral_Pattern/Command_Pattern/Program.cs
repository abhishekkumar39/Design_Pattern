﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Pattern
{
    class Reciver
    {
        public void Action()
        {
            Console.WriteLine("Reciver is performing an Action");
        }
    }
    interface ICommand
    {
        void Execute();
    }

    class ConcreteCommand : ICommand
    {
        private Reciver _reciver;

        public ConcreteCommand(Reciver reciver)
        {
            _reciver = reciver;
        }
        public void Execute()
        {
            _reciver.Action();
        }
    }
    class Invoker
    {
        private List<ICommand> _commands = new List<ICommand>();
        public void StoreAndExcute(ICommand Command)
        {
            _commands.Add(Command);
            Command.Execute();
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            Reciver reciver = new Reciver();
            ICommand command = new ConcreteCommand(reciver);
            Invoker invoker=new Invoker();
            invoker.StoreAndExcute(command);
            Console.ReadKey();
        }
    }
}
