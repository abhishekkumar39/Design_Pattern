﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Interpreter_Pattern
{
    class Context
    {
        public string Input { get; set; }
        public int Output { get; set; }

        public Context(string input)
        { 
            Input = input;
        }
    }

    abstract class Expression
    {
        public abstract void Interpret(Context context);
    }

    class NumberExpression : Expression
    {
        private readonly int _number;
        public NumberExpression(int number)
        {

            _number = number;
        }
        public override void Interpret(Context context)
        {
            context.Output = _number;
        }
    }

    class PlusExpression : Expression
    {
        private readonly Expression _expression1;
        private readonly Expression _expression2;

        public PlusExpression(Expression expression1, Expression expression2)
        {
            _expression1 = expression1;
            _expression2 = expression2;
        }
        public override void Interpret(Context context)
        {
            _expression1.Interpret(context);
            int result1 = context.Output;
            _expression2.Interpret(context);
            int result2 = context.Output;
            context.Output = result1 + result2;
        }
    }


    public class Program
    {
        static void Main(string[] args)
        {
            string input = "1 2 + 3 + 6 +";
            Context context = new Context(input);

            Stack<Expression> expressions = new Stack<Expression>();
            string[] tokens = input.Split(' ');

            foreach (string token in tokens)
            {
                if (token == "+")
                {
                    Expression expression1 = expressions.Pop();
                    Expression expression2 = expressions.Pop();
                    expressions.Push(new PlusExpression(expression1, expression2));
                }
                else
                {
                    expressions.Push(new NumberExpression(int.Parse(token)));
                }
            }
            Expression syntaxTree = expressions.Pop();
            syntaxTree.Interpret(context);

            Console.WriteLine($"Result : {context.Output}");
            Console.ReadKey();
        }
    }
}

