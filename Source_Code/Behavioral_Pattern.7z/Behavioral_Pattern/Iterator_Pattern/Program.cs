﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iterator_Pattern
{
    interface IAbstractCollection
    {
        Iterator CreateIterator();
    }
    interface Iterator
    {
        object First();
        object Next();
        bool IsDone();
        Object CurrentItem();
    }
    class ConcreteCollection : IAbstractCollection
    {
        private ArrayList _items = new ArrayList();
        public Iterator CreateIterator()
        {
            return new ConcreteIterator(this);
        }
        public int Count
        {
            get { return _items.Count; }
        }
        public object this[int index]
        {
            get { return _items[index]; }
            set { _items.Insert(index, value); }
        }
    }
    class ConcreteIterator : Iterator
    {
        private ConcreteCollection _collection;
        private int _current = 0;

        public ConcreteIterator(ConcreteCollection collection)
        {
            this._collection = collection;
        }
        public object First()
        {
            _current = 0;
            return _collection[_current];
        }
        public object Next()
        {
            _current++;
            if (_current < _collection.Count)
            {
                return _collection[_current];
            }
            else
            {
                return null;
            }
        }
        public object CurrentItem()
        {
            return _collection[_current];
        }
        public bool IsDone()
        { 
            return _current >=_collection.Count;    
        }
    }

    public class Program
    {
        static void Main(string[] args)
        {
            ConcreteCollection collection = new ConcreteCollection();
            collection[0] = "item 1";
            collection[1] = "item 2";
            collection[2] = "item 3";
            collection[3] = "item 4";
            Iterator iterator=collection.CreateIterator();
            Console.WriteLine("Iterating over collection");
            for (object item = iterator.First(); !iterator.IsDone(); item=iterator.Next())
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();
        }
    }
}
