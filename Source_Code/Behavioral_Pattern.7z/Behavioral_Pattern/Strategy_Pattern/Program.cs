﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strategy_Pattern
{
    public interface IShippingStrategy
    {
        double CalculateShippingCost(double orderAmount);
    }
    public class FedExShippingStrategy : IShippingStrategy
    {
        public double CalculateShippingCost(double orderAmount)
        {
            return 0.05 * orderAmount + 5;

        }
    }
    public class UPShippingStrategy : IShippingStrategy
    {
        public double CalculateShippingCost(double orderAmount)
        {
            return 0.07 * orderAmount + 2;
        }
    }
    public class UPSShippingStrategy : IShippingStrategy
    {
        public double CalculateShippingCost(double orderAmount)
        {
            return 0.06 * orderAmount + 3;
        }
    }
    public class ShoppingCart
    {
        private IShippingStrategy _shippingStrategy;
        public ShoppingCart(IShippingStrategy shippingStrategy)
        {
            _shippingStrategy = shippingStrategy;
        }
        public double CalculateShippingCost(double orderAmount)
        {
            return _shippingStrategy.CalculateShippingCost(orderAmount);
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            ShoppingCart cart1=new ShoppingCart(new FedExShippingStrategy());
            ShoppingCart cart2 = new ShoppingCart(new FedExShippingStrategy());
            ShoppingCart cart3 = new ShoppingCart(new FedExShippingStrategy());

            double orderAmount1 = 100;
            double orderAmount2 = 200;
            double orderAmount3 = 300;
            Console.WriteLine("Shipping cost for Cart 1: $"+ cart1.CalculateShippingCost(orderAmount1));
                Console.WriteLine("Shipping cost for Cart 1: $" + cart2.CalculateShippingCost(orderAmount2));
            Console.WriteLine("Shipping cost for Cart 1: $" + cart3.CalculateShippingCost(orderAmount3));
            Console.ReadKey();
        }
    }
}





