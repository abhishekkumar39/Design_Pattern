﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade_Pattern
{
    class CPU
    {
        public void Operation1()
        {
            Console.WriteLine("CPU Operation1");
        }
    }
    class Memory
    {
        public void Operation2()
        {
            Console.WriteLine("Memory Operation2");
        }
        class HardDrive
        {
            public void Operation3()
            {
                Console.WriteLine("HardDrive Operation3");
            }
        }
        class Computer
        {
            private CPU cpu;
            private Memory memory;
            private HardDrive hardDrive;

            public Computer()
            {

                cpu = new CPU();
                memory = new Memory();
                hardDrive = new HardDrive();
            }
            public void Operation()
            {
                Console.WriteLine("Computer Operation");
                cpu.Operation1();
                memory.Operation2();
                hardDrive.Operation3();
            }
        }
        class Client
        {
            public class Program
            {
                static void Main(string[] args)
                {
                    Computer computer = new Computer();
                    computer.Operation();
                    Console.ReadKey();
                }
            }
        }
    }
}