﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy_Pattern
{
    public interface IImage
    {
        void Request();
    }
    public class RealImage : IImage
    {
        public void Request()
        {
            Console.WriteLine("RealImage : Handling Request");
        }
    }
    public class ProxyImage : IImage
    {
        public void Request()
        {
            Console.WriteLine("ProxyImage : Handling Request");
        }
    }


    public class Proxy : IImage
    {
        private RealImage realImage;
        private ProxyImage proxyImage;

        public void Request()
        {
            if (realImage == null)
            {
                Console.WriteLine("Proxy : Creating RealImage");
                realImage = new RealImage();
            }

            Console.WriteLine("Proxy : Forwading request to RealImage.");
            realImage.Request();
        }
        public void Request1()
        {
            if (proxyImage == null)
            {
                Console.WriteLine("Proxy : Creating ProxyImage");
                proxyImage = new ProxyImage();
            }

            Console.WriteLine("Proxy : Forwading request to ProxyImage.");
            proxyImage.Request();
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Proxy proxy = new Proxy();
            proxy.Request();
            proxy.Request1();
            Console.ReadKey();
        }
    }
}
