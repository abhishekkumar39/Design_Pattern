﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Payment_System_Factory_Method
{
    public interface IPayment

    {

        void DisplayInfo();

    }

    public class ConcreteCredit_Card : IPayment

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Amount is Credited");

            Console.ReadLine();

        }

    }

    public class ConcreteDebit_Card : IPayment

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Amount is Debited");

            Console.ReadLine();

        }

    }

    public class ConcreteUPI : IPayment

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Amount is Transected by UPI");

            Console.ReadLine();

        }

    }
    public class ConcreteNet_Banking : IPayment

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Amount is Transfer by Net Banking");

            Console.ReadLine();

        }

    }
    public class ConcreteWallet : IPayment

    {

        public void DisplayInfo()

        {

            Console.WriteLine("Amount is Added in wallet");

            Console.ReadLine();

        }

    }

    public interface IAbstractFactory

    {

        IPayment CreatePayment();

      

    }

    public class ConcreteFactory1 : IAbstractFactory

    {

        public IPayment CreatePayment()

        {

            return new ConcreteCredit_Card();

        }
    }


    public class ConcreteFactory2 : IAbstractFactory

    {

        public IPayment CreatePayment()

        {

            return new ConcreteDebit_Card();

        }

    }
    public class ConcreteFactory3 : IAbstractFactory

    {

        public IPayment CreatePayment()

        {

            return new ConcreteUPI();

        }
    }
    public class ConcreteFactory4 : IAbstractFactory

    {

        public IPayment CreatePayment()

        {

            return new ConcreteNet_Banking();

        }
    }
    public class ConcreteFactory5 : IAbstractFactory

    {

        public IPayment CreatePayment()

        {

            return new ConcreteWallet();

        }
    }

    public class Program

    {

        static void Main(string[] args)

        {

            IAbstractFactory factory1 = new ConcreteFactory1();
            IAbstractFactory factory2 = new ConcreteFactory2();
            IAbstractFactory factory3 = new ConcreteFactory3();
            IAbstractFactory factory4 = new ConcreteFactory4();
            IAbstractFactory factory5 = new ConcreteFactory5();


            IPayment iCredit_Card = factory1.CreatePayment();
            IPayment iDebit_Card = factory2.CreatePayment();
            IPayment iNet_Banking = factory3.CreatePayment();
            IPayment iUPI = factory4.CreatePayment();
            IPayment iWallet = factory5.CreatePayment();
            iCredit_Card.DisplayInfo();
            iDebit_Card.DisplayInfo();
            iNet_Banking.DisplayInfo();
            iUPI.DisplayInfo();
            iWallet.DisplayInfo();


        }

    }

}

