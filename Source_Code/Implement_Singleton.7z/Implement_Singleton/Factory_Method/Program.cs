﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factory_Method
{
    public interface IVehcile
    {
        void ShowInfo();
    }
    public class Car : IVehcile
    {
        public void ShowInfo()
        {
            Console.WriteLine("Brand=Toyota, Model= Fortuner,Color=Black");
            Console.ReadKey();
        }
    }
    public class Bike : IVehcile
    {
        public void ShowInfo()
        {
            Console.WriteLine("Brand=Honda, Model=Shine,Color=Black");
            Console.ReadKey();
        }
    }

    public class Truck : IVehcile
    {
        public void ShowInfo()
        {
            Console.WriteLine("Brand=Tata, Model= 407,Color=Red");
            Console.ReadKey();
        }
    }
    public class Bus : IVehcile
    {
        public void ShowInfo()
        {
            Console.WriteLine("Brand=Volvo, Model=2200,Color=White");
            Console.ReadKey();
        }
    }


    public abstract class Creator
    {
        public abstract IVehcile FactoryMethod();
    }
    public class ConcreteCreatorA : Creator
    {
        public override IVehcile FactoryMethod()
        {
            return new Car();
        }
    }
    public class ConcreteCreatorB : Creator
    {
        public override IVehcile FactoryMethod()
        {
            return new Bike();
        }
    }
    public class ConcreteCreatorC : Creator
    {
        public override IVehcile FactoryMethod()
        {
            return new Truck();
        }
    }
    public class ConcreteCreatorD : Creator
    {
        public override IVehcile FactoryMethod()
        {
            return new Bus();
        }
    }



    public class Program
    {
        static void Main(string[] args)
        {
            Creator creatorA = new ConcreteCreatorA();
            IVehcile Car = creatorA.FactoryMethod();
            Car.ShowInfo();
            Creator creatorB = new ConcreteCreatorB();
            IVehcile Bike = creatorB.FactoryMethod();
            Bike.ShowInfo();
            Creator creatorC = new ConcreteCreatorC();
            IVehcile Truck = creatorC.FactoryMethod();
            Truck.ShowInfo();
            Creator creatorD = new ConcreteCreatorD();
            IVehcile Bus = creatorD.FactoryMethod();
            Bus.ShowInfo();



        }
    }

}
