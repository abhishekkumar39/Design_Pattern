﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootBall_Prototype_Pattern
{
    public interface IFootball
    {
        IFootball Clone();

    }
    public class ConcretePlayer : IFootball
    {
        
        public int ID { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public int Goal { get; set; }
               


        public ConcretePlayer(int id,string name, string position , int goal)
        {
            ID = id;
            Name = name;
            Position = position;
            Goal = goal;
        }

        public IFootball Clone()
        {
            return (IFootball)this.MemberwiseClone();
        }
        public void DisplayInfo()
        {
            Console.WriteLine($"ID:{ID}, Name:{Name}, Position:{Position},Goal:{Goal}");
        }

        public class Program
        {
            static void Main(string[] args)
            {
                ConcretePlayer prototype = new ConcretePlayer(1, "Abhishek", "Midfeilder", 2 );
                prototype.DisplayInfo();

                ConcretePlayer player1 = (ConcretePlayer)prototype.Clone();
                player1.Name = "Hiamnshu";
                ConcretePlayer player2 = (ConcretePlayer)prototype.Clone();
                player2.Name = "Kumar";
                ConcretePlayer player3 = (ConcretePlayer)prototype.Clone();
                player3.Name = "Ayush";
                player1.DisplayInfo();
                player2.DisplayInfo();
                player3.DisplayInfo();
                

                



            }
        }
    }

}