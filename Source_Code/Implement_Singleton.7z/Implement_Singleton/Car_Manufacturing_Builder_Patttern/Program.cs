﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Car_Manufacturing_Builder_Patttern
{
    public class Car
    {
        public string Engine { get; set; }
        public string Cabinet { get; set; }
        public string Seat { get; set; }
        public string Final_Product { get; set; }

        public void ShowInfo()
        {
            Console.WriteLine($" Engine : {Engine}");
            Console.WriteLine($" Cabinet : {Cabinet}");
            Console.WriteLine($" Seat : {Seat}");
            Console.WriteLine($" Final Product : {Final_Product}");
        }
    }

    public abstract class Builder
    {
        public abstract void BuilEngine();
        public abstract void BuilCabinet();
        public abstract void BuilSeat();
        public abstract void BuilFinal_Product();
        public abstract Car GetResult();
    }

    public class ConcreteBuilder : Builder
    {
        private Car car = new Car();
        public override void BuilEngine()
        {
            car.Engine = "Engine built";
        }
        public override void BuilCabinet()
        {
            car.Cabinet = "Cabinet built";
        }
        public override void BuilSeat()
        {
            car.Seat = "Seat built";
        }
        public override void BuilFinal_Product()
        {
            car.Final_Product = "Car is built";
        }
        public override Car GetResult()
        {
            return car;
        }
    }

    public class Director
    {
        private Builder builder;

        public Director(Builder builder)
        {
            this.builder = builder;
        }

        public void Construct()
        {
            builder.BuilEngine();
            builder.BuilCabinet();
            builder.BuilSeat();
            builder.BuilFinal_Product();
        }

    }

    public class Program
    {
        static void Main(string[] args)
        {

            Builder builder = new ConcreteBuilder();
            Director director = new Director(builder);
            director.Construct();

            Car car = builder.GetResult();
            car.ShowInfo();
            Console.WriteLine();
        }
    }
}

