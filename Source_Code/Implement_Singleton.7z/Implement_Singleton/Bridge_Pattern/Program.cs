﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge_Pattern
{
    public abstract class Shape
    {
        protected IRenderer renderer;

        public Shape(IRenderer renderer)
        {
            this.renderer = renderer;
        }

        public abstract void Draw();
    }

    public class Circle : Shape
    {
        public Circle(IRenderer renderer) : base(renderer) { }

        public override void Draw()
        {
            renderer.RenderCircle(this);
        }
    }

    public interface IRenderer
    {
        void RenderCircle(Shape shape);
    }
    public class VectorRenderer : IRenderer
    {
        public void RenderCircle(Shape shape)
        {
            Console.WriteLine("Drawing circle using vector renderer");
        }
    }
    public class RasterRenderer : IRenderer
    {
        public void RenderCircle(Shape shape)
        {
            Console.WriteLine("Drawing circle using raster renderer");
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Shape circle = new Circle(new VectorRenderer());
            circle.Draw(); 
            Shape circle2 = new Circle(new RasterRenderer());
            circle2.Draw(); 
           
        }
    }
}