﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite_Pattern
{
    public interface IFileComponent
    {
        void Display(int depth);
    }

    public class File : IFileComponent
    {
        private string name;
        public File(string name)
        {
            this.name = name;
        }

        public void Display(int depth)
        {
            Console.WriteLine(new string(' ', depth) + name);
        }
    }

    public class Directory : IFileComponent
    {
        private string name;
        private List<IFileComponent> children = new List<IFileComponent>();
        public Directory(string name)
        {
            this.name = name;
        }

        public void Add(IFileComponent component)
        {
            children.Add(component);
        }
        public void Remove(IFileComponent component)
        {
            children.Remove(component);
        }
        public void Display(int depth)
        {
            Console.WriteLine(new String('-', depth) + name);

            foreach (var component in children)
            {
                component.Display(depth + 2);
            }
        }
        public class Program
        {
            static void Main(string[] args)
            {
                Directory root = new Directory("Root");
                root.Add(new File("File A"));
                root.Add(new File("File B"));

                Directory compositeX = new Directory("Composite X");
                compositeX.Add(new File("File XA"));
                compositeX.Add(new File("File XB"));

                Directory compositeY = new Directory("Composite X");
                compositeY.Add(new File("File YA"));
                compositeY.Add(new File("File YB"));

                root.Add(compositeX);
                root.Add(compositeY);

                root.Display(0);
                root.Display(1);
            }
        }
    }
}

