﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Implement_Singleton
{
    public class Singleton
    {
        private static Singleton instance;
        private Singleton()
        {
            Console.WriteLine($"Singleton is Instantiated");
        }

        public static Singleton GetInstance()
        {
            if (instance == null)
            {
                instance = new Singleton();
            }
            return instance;
        }


        public void DoSomething()
        {
            Console.WriteLine($"Something is Done");
        }
    }
}