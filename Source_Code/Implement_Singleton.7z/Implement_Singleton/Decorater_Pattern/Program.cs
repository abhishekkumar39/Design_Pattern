﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Decorater_Pattern
{
    public interface IMessage
    {
        string SendMessage();
    }

    public class TextMessage : IMessage
    {
        private string message;

        public TextMessage(string message)
        {
            this.message = message;
        }

        public string SendMessage()
        {
            return message;
        }
    }

    public abstract class MessageDecorator : IMessage
    {
        protected IMessage message;

        public MessageDecorator(IMessage message)
        {
            this.message = message;
        }

        public abstract string SendMessage();
    }

    public class EncryptedMessage : MessageDecorator
    {
        public EncryptedMessage(IMessage message) : base(message) { }

        public override string SendMessage()
        {
            string encryptedMessage = Encrypt(message.SendMessage());
            return encryptedMessage;
        }

        private string Encrypt(string message)
        {

            char[] array = message.ToCharArray();
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = (char)(array[i] + 1);
            }
            return new string(array);
        }
    }

    public class CompressedMessage : MessageDecorator
    {
        public CompressedMessage(IMessage message) : base(message) { }

        public override string SendMessage()
        {
            string compressedMessage = Compress(message.SendMessage());
            return compressedMessage;
        }

        private string Compress(string message)
        {

            return message.Substring(0, message.Length / 2);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IMessage message = new TextMessage("Hello World!");
            Console.WriteLine("Original Message: " + message.SendMessage());

            IMessage encryptedMessage = new EncryptedMessage(message);
            Console.WriteLine("Encrypted Message: " + encryptedMessage.SendMessage());

            IMessage compressedMessage = new CompressedMessage(message);
            Console.WriteLine("Compressed Message: " + compressedMessage.SendMessage());

            IMessage encryptedAndCompressedMessage = new CompressedMessage(new EncryptedMessage(message));
            Console.WriteLine("Encrypted and Compressed Message: " + encryptedAndCompressedMessage.SendMessage());
        }
    }

}

