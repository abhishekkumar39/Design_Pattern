﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Question_Adapter_Pattern
{
    public class PaymentGateway
    {
        public void ProcessOldPayment(string accountNumber, double amount)
        {
            Console.WriteLine($"Processing payment of {amount} for account {accountNumber} using the old system.");
        }
    }
    public interface IPayment
    {
        void ProcessPayment(string accountNumber, double amount);
    }

    public class PaymentAdapter : IPayment
    {
        private readonly PaymentGateway _paymentGateway;

        public PaymentAdapter(PaymentGateway paymentGateway)
        {
            _paymentGateway = paymentGateway;
        }

        public void ProcessPayment(string accountNumber, double amount)
        {
            _paymentGateway.ProcessOldPayment(accountNumber, amount);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            PaymentGateway legacyGateway = new PaymentGateway();

            IPayment payment = new PaymentAdapter(legacyGateway);

            payment.ProcessPayment("1234", 100);
        }
    }
}

