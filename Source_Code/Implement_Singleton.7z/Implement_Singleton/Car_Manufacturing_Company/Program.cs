﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Manufacturing_Company
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
