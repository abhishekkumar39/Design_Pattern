﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Document_Managment_System_Factory_Method_
{
    public interface IDocument
    {
        string Name { get; }
        string Size { get; }
        string Date { get; }
        void DisplayInfo();
    }
    public class PDFDocument : IDocument
    {
        public string Name { get; }
        public string Size { get; }
        public string Date { get; }

        public PDFDocument(string name, string size, string date)
        {
            Name = name;
            Size = size;
            Date = date;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"PDF Document: {Name}, Size: {Size}, Date: {Date}");
        }
    }

    public class WordDocument : IDocument
    {
        public string Name { get; }
        public string Size { get; }
        public string Date { get; }

        public WordDocument(string name, string size, string date)
        {
            Name = name;
            Size = size;
            Date = date;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Word Document: {Name}, Size: {Size}, Date: {Date}");
        }
    }
    public class TextDocument : IDocument
    {
        public string Name { get; }
        public string Size { get; }
        public string Date { get; }

        public TextDocument(string name, string size, string date)
        {
            Name = name;
            Size = size;
            Date = date;
        }
        public void DisplayInfo()
        {
            Console.WriteLine($"Text Document: {Name}, Size: {Size}, Date: {Date}");
        }
    }
    public class XMLDocument : IDocument
    {
        public string Name { get; }
        public string Size { get; }
        public string Date { get; }

        public XMLDocument(string name, string size, string date)
        {
            Name = name;
            Size = size;
            Date = date;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"XML Document: {Name}, Size: {Size}, Date: {Date}");
        }
    }

    public abstract class DocumentFactory
    {
        public abstract IDocument CreateDocument(string name, string size, string date);
    }

    public class PDFDocumentFactory : DocumentFactory
    {
        public override IDocument CreateDocument(string name, string size, string date)
        {
            return new PDFDocument(name, size, date);
        }
    }

    public class WordDocumentFactory : DocumentFactory
    {
        public override IDocument CreateDocument(string name, string size, string date)
        {
            return new WordDocument(name, size, date);
        }
    }

    public class TextDocumentFactory : DocumentFactory
    {
        public override IDocument CreateDocument(string name, string size, string date)
        {
            return new TextDocument(name, size, date);
        }
    }

    public class XMLDocumentFactory : DocumentFactory
    {
        public override IDocument CreateDocument(string name, string size, string date)
        {
            return new XMLDocument(name, size, date);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            DocumentFactory pdfFactory = new PDFDocumentFactory();
            IDocument pdfDoc = pdfFactory.CreateDocument("Document.pdf", "5MB", "20-Aug-2024");
            pdfDoc.DisplayInfo();

            DocumentFactory wordFactory = new WordDocumentFactory();
            IDocument wordDoc = wordFactory.CreateDocument("Document.docx", "1MB", "29-Aug-2024");
            wordDoc.DisplayInfo();

            DocumentFactory textFactory = new TextDocumentFactory();
            IDocument textDoc = textFactory.CreateDocument("Document.txt", "2MB", "16-Aug-2024");
            textDoc.DisplayInfo();

            DocumentFactory xmlFactory = new XMLDocumentFactory();
            IDocument xmlDoc = xmlFactory.CreateDocument("Document.xml", "200KB", "12-Aug-2024");
            xmlDoc.DisplayInfo();
        }
    }
}