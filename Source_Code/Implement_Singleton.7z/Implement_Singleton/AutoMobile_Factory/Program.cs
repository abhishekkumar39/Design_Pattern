﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Automobile_Interface
{
    public interface IVehicle
    {
        string Brand { get; set; }
        string Model { get; set; }
        string Colour { get; set; }
        void ShowDetails();
    }


    public class Car : IVehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Colour { get; set; }

        public void ShowDetails()
        {
            Console.WriteLine($"Car Details: Brand = {Brand}, Model = {Model}, Colour = {Colour}");
        }
    }

    public class Bike : IVehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Colour { get; set; }

        public void ShowDetails()
        {
            Console.WriteLine($"Bike Details: Brand = {Brand}, Model = {Model}, Colour = {Colour}");
        }
    }

    public class Truck : IVehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Colour { get; set; }

        public void ShowDetails()
        {
            Console.WriteLine($"Truck Details: Brand = {Brand}, Model = {Model}, Colour = {Colour}");
        }
    }

    public class Bus : IVehicle
    {
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Colour { get; set; }

        public void ShowDetails()
        {
            Console.WriteLine($"Bus Details: Brand = {Brand}, Model = {Model}, Colour = {Colour}");
        }
    }

    public abstract class VehicleFactory
    {
        public abstract IVehicle CreateVehicle();
    }

    public class CarFactory : VehicleFactory
    {
        public override IVehicle CreateVehicle()
        {
            return new Car();
        }
    }

    public class BikeFactory : VehicleFactory
    {
        public override IVehicle CreateVehicle()
        {
            return new Bike();
        }
    }

    public class TruckFactory : VehicleFactory
    {
        public override IVehicle CreateVehicle()
        {
            return new Truck();
        }
    }

    public class BusFactory : VehicleFactory
    {
        public override IVehicle CreateVehicle()
        {
            return new Bus();
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the type of vehicle (Car, Bike, Truck, Bus): ");
            string vehicleType = Console.ReadLine();

            VehicleFactory factory = null;

            switch (vehicleType.ToLower())
            {
                case "car":
                    factory = new CarFactory();
                    break;
                case "bike":
                    factory = new BikeFactory();
                    break;
                case "truck":
                    factory = new TruckFactory();
                    break;
                case "bus":
                    factory = new BusFactory();
                    break;
                default:
                    Console.WriteLine("Invalid vehicle type.");
                    return;
            }

            IVehicle vehicle = factory.CreateVehicle();

            Console.WriteLine("Enter the brand: ");
            vehicle.Brand = Console.ReadLine();

            Console.WriteLine("Enter the model: ");
            vehicle.Model = Console.ReadLine();

            Console.WriteLine("Enter the colour: ");
            vehicle.Colour = Console.ReadLine();
            vehicle.ShowDetails();
        }

    }
}